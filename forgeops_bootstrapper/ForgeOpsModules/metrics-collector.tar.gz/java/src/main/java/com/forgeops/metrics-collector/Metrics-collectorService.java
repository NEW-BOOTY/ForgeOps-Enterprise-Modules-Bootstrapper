package com.forgeops.metrics-collector;\npublic class Metrics-collectorService {\n public void start() { System.out.println("metrics-collector service started"); }\n}
