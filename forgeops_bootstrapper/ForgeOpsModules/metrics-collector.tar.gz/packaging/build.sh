#!/usr/bin/env bash\ntar -czf metrics-collector.tar.gz .
