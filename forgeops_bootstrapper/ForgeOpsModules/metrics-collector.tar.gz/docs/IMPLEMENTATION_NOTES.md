Module metrics-collector scaffolded with Java and Python stubs.
