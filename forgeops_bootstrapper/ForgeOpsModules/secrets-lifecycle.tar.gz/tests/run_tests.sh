#!/usr/bin/env bash\necho 'Running tests for secrets-lifecycle...'
