#!/usr/bin/env bash\ntar -czf secrets-lifecycle.tar.gz .
