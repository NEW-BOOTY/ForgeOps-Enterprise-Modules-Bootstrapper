#!/usr/bin/env bash\necho 'CI build stub for ci-cd...'
