package com.forgeops.ci-cd;\npublic class Ci-cdService {\n public void start() { System.out.println("ci-cd service started"); }\n}
