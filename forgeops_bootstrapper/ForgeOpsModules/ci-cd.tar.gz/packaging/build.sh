#!/usr/bin/env bash\ntar -czf ci-cd.tar.gz .
