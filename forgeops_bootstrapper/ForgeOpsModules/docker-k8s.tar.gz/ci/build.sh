#!/usr/bin/env bash\necho 'CI build stub for docker-k8s...'
