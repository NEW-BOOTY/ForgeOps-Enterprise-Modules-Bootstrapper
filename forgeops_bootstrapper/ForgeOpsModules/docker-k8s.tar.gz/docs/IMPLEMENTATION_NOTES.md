Module docker-k8s scaffolded with Java and Python stubs.
