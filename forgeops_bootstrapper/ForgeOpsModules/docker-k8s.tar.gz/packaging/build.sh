#!/usr/bin/env bash\ntar -czf docker-k8s.tar.gz .
