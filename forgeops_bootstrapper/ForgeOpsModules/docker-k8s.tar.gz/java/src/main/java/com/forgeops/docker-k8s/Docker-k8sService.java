package com.forgeops.docker-k8s;\npublic class Docker-k8sService {\n public void start() { System.out.println("docker-k8s service started"); }\n}
