#!/usr/bin/env bash\necho 'Running tests for docker-k8s...'
