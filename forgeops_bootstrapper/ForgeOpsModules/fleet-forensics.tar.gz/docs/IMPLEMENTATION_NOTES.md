Module fleet-forensics scaffolded with Java and Python stubs.
