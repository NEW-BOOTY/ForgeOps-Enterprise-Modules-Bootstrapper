#!/usr/bin/env bash\ntar -czf fleet-forensics.tar.gz .
