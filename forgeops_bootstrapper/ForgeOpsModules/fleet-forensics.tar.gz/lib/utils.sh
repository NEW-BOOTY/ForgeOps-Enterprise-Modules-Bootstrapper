#!/usr/bin/env bash\n# Utility functions
